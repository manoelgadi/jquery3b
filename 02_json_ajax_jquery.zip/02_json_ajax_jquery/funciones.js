const request = new XMLHttpRequest();

//request.open('TIPO','URL') - HandShake! 
// TIPO: GET, POST, PUT, DELETE.

request.open('GET','https://jsonplaceholder.typicode.com/photos'); // HandShake! 
request.send();  //Leyendo los datos.

// request.onreadystatechange = () => {}

request.onreadystatechange = (e) => {
	if(request.readyState === 4){
		const fotos = JSON.parse(request.responseText);		
		//fotos.forEach(FUNCION)
		// fotos.forEach(()=>{})
		var nf;
		fotos.forEach((foto)=>{
			$("#table_body").append('<tr id="nf"> </tr>');
			nf = $("#nf");
			nf.append('<td> '+foto['albumId']+' </td>');
			nf.append('<td> '+foto['id']+' </td>');
			nf.append('<td> '+foto['title']+' </td>');
			nf.append('<td> <img src="'+foto['thumbnailUrl']+'"> </img></td>');			
			nf.removeAttr('id');
		})
	}
}
